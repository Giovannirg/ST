#include <avr/io.h>
#include <stdint.h>
#include <stdio.h>
#include <avr/interrupt.h>
#include "lcd.h"

extern volatile uint16_t ms;
extern volatile uint8_t ss;
extern volatile uint8_t mm;
extern volatile uint8_t hh;
extern int tick();
char a[14];
void Init_Timer()
{
	TCCR1A |= 0;
	//prescaler 64
	TCCR1B |= (1 << WGM12) | (1 << CS11) | (1 << CS10);
	//OCR1A = 12000000Hz/(64*1000Hz)-1= 186,5
	OCR1A = 186;
	TIFR |= (1 << OCF1A) | (1 << OCF1B);
	TIMSK |= (1 << OCIE1A);
}
int pause = 1;
int main(void)
{
	
	LCD_init();
	Init_Timer();
	DDRB &= ~(1<<PB0);
	PORTB |= (1<<PB0);
	int counter = 0;
	hh = mm = ss = ms = 0;
	sei();
	int init = 1;
	int pause2 = 0;
	while(1)
	{
		while(!(PINB & (1<<PB0)))
		{
			pause = 1;
			counter++;
			_delay_ms(200);
			if(init == 0)
			{
				pause2 = 1;
				init = 1;
			}
			else
			{
				pause2 = 0;
			}
		}
		if((counter <= 10) && (counter != 0) && (pause2 != 1))
		{
			pause = 0;
			init = 0;
		}
		if(counter > 10)
		{
			pause = 1;
			hh = mm = ss = ms = 0;
			init = 1;
			sprintf(a, "%02d:%02d:%02d:%03d", hh, mm, ss, ms);
			LCD_string(a);
			LCD_cursor(0,0);
		}
		counter = 0;
	}	
}

ISR(TIMER1_COMPA_vect)
   {
	   if(pause == 0)
	   {
		   tick();
		   sprintf(a, "%02d:%02d:%02d:%03d", hh, mm, ss, ms);
		   LCD_string(a);
		  LCD_cursor(0,0);
	   }
   
   }


