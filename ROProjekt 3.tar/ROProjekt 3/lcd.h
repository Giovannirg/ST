
#ifndef LCD_H_
#define LCD_H_
#include <avr/io.h>
#define F_CPU 12000000
#include <util/delay.h>

//Display RS Pin connect
// to Atmega GPO pin PC0
#define RS_BIT	(1<<PC0)
#define RS_PORT	 PORTC
#define RS_DDR	DDRC

//Dispay CSB Pin connect
// to Atmega GPO pin PC1
#define SS0_BIT (1<<PC1)
#define SS0_PORT PORTC
#define SS0_DDR DDRC

// Initialisierung der IO Pins
// der SPI Kommunikation
// des Displays 
void LCD_init();

// ausgabe eines Zeichens
void LCD_char(char c);

// Ausgabe einer Zeichenkette wie "Hello"
void LCD_string(char *str);

// setzt die Schreibposition, oben links ist (0,0)
int LCD_cursor(unsigned int line, unsigned int col);

void LCD_command(uint8_t cmd);

#endif /* LCD_H_ */
