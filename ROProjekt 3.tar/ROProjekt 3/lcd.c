#include <avr/io.h>
#define F_CPU 12000000
#include <util/delay.h>
#include "lcd.h"

void LCD_command(uint8_t cmd)
{
	SS0_PORT &= ~SS0_BIT;			//CSB low
	RS_PORT &= ~RS_BIT;				//RS low
	SPDR = cmd;						//the byte to be sent
	while (!(SPSR & (1<<SPIF)));	//wait for send complete
	SS0_PORT|= SS0_BIT;				//CSB high
	_delay_us(26.3);				//wait
}

void LCD_init()
{
	RS_DDR |= RS_BIT;	//outp
	RS_PORT |= RS_BIT; //high
	
	SS0_DDR |= SS0_BIT; //outp
	SS0_PORT |= SS0_BIT; //high
	
	DDRB &= ~(1<<PB2);
	PORTB |= (1<<PB2);
	
	DDRB |= (1<<PB5);
	PORTB |= (1<<PB5);
	
	DDRB |= (1<<PB3);
	PORTB |= (1<<PB3);
	
	

	SPCR = (1<<SPE) | (0<<DORD) | (1<<MSTR) | (1<<CPOL) | (1<<CPHA) | (1<<SPR1) | (0<<SPR0);
	_delay_ms(250);
	LCD_command(0x39);		//function set
	LCD_command(0x1C);		//bias set
	LCD_command(0x52);		//power control
	LCD_command(0x69);		//follower control
	LCD_command(0x74);		//contrast set
	LCD_command(0x38);		//function set
	LCD_command(0x0F);		//display ON/OFF
	LCD_command(0x01);		//clear display
	_delay_ms(1.08);
	LCD_command(0x06);		//entry mode set
}



int LCD_cursor(unsigned int line, unsigned int col)
{
	if((line > 1) || (col>15))
		return -1; //error
	//set DDRAM address command
	LCD_command(0x80 + 0x40*line + col);
	return 0; //OK
}

void LCD_char(char c)
{
	SS0_PORT &= ~SS0_BIT;			//CSB low
	RS_PORT |= RS_BIT;			//RS high
	SPDR = c;						//the byte to be sent
	while (!(SPSR & (1<<SPIF)));	//wait for send complete
	SS0_PORT|= SS0_BIT;				//CSB high
	_delay_us(26.3);				//wait
}

void LCD_string(char *str)
{
	while(*str)
	{
		LCD_char(*str++);
	}
}